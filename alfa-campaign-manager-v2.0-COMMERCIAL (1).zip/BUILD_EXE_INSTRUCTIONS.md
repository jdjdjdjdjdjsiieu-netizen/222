# 🔨 Инструкция по созданию исполняемого .exe файла

## Для Windows пользователей

### Вариант 1: Использовать готовые скрипты (рекомендуется)

**Просто дважды кликните на:**
- **START.bat** - автоматический запуск проекта

Этот файл:
1. ✅ Проверит Python
2. ✅ Установит зависимости
3. ✅ Запустит Setup Wizard (если нужно)
4. ✅ Откроет браузер с интерфейсом настройки
5. ✅ Запустит приложение

**Никаких дополнительных действий не требуется!**

---

### Вариант 2: Создать .exe файл с PyInstaller

Если вы хотите создать **один исполняемый файл** (.exe) для распространения:

#### Шаг 1: Установить PyInstaller

```bash
pip install pyinstaller
```

#### Шаг 2: Запустить сборку

```bash
python build_exe.py
```

#### Шаг 3: Найти готовый .exe

После сборки файл будет здесь:
```
dist/AlfaCampaignManager.exe
```

Размер: ~50-100 MB (включает Python и все зависимости)

#### Шаг 4: Использование

1. Скопируйте `AlfaCampaignManager.exe` в папку проекта
2. Дважды кликните на `AlfaCampaignManager.exe`
3. Приложение автоматически:
   - Проверит зависимости
   - Запустит Setup Wizard (при первом запуске)
   - Откроет браузер с интерфейсом
   - Запустит сервер

---

### Вариант 3: Ручная сборка с PyInstaller

Если вы хотите настроить сборку вручную:

```bash
# Базовая сборка
pyinstaller --onefile --name AlfaCampaignManager launcher.py

# С иконкой (если есть)
pyinstaller --onefile --name AlfaCampaignManager --icon=icon.ico launcher.py

# Без консоли (GUI режим)
pyinstaller --onefile --noconsole --name AlfaCampaignManager launcher.py

# С дополнительными файлами
pyinstaller --onefile --name AlfaCampaignManager \
  --add-data "requirements.txt:." \
  --add-data ".env:." \
  launcher.py
```

---

## Для Linux/macOS пользователей

### Использовать готовые скрипты

```bash
# Сделать исполняемым (один раз)
chmod +x start.sh

# Запустить
./start.sh
```

ИЛИ

```bash
# Универсальный Python launcher
python3 launcher.py
```

---

## Что делает каждый файл

### START.bat (Windows)
- ✅ Проверяет Python
- ✅ Устанавливает зависимости
- ✅ Запускает Setup Wizard
- ✅ Открывает браузер
- ✅ Запускает приложение

### start.sh (Linux/macOS)
- То же самое, что START.bat, но для Unix систем

### launcher.py (Кроссплатформенный)
- Универсальный Python скрипт
- Работает на всех платформах
- Можно превратить в .exe с PyInstaller

### build_exe.py
- Автоматизирует создание .exe файла
- Использует PyInstaller
- Создает готовый к распространению .exe

---

## Преимущества каждого варианта

### START.bat / start.sh
✅ **Преимущества:**
- Не требует сборки
- Легко редактировать
- Маленький размер
- Быстрый запуск

❌ **Недостатки:**
- Требует установленный Python
- Видна консоль

### .exe файл (PyInstaller)
✅ **Преимущества:**
- Не требует установленный Python
- Один файл для распространения
- Выглядит профессионально
- Можно добавить иконку

❌ **Недостатки:**
- Большой размер (~50-100 MB)
- Требует сборки
- Дольше запускается

---

## Рекомендации

### Для личного использования:
👉 Используйте **START.bat** (Windows) или **start.sh** (Linux/macOS)

### Для распространения клиентам:
👉 Создайте **.exe файл** с помощью **build_exe.py**

### Для разработки:
👉 Используйте **launcher.py** напрямую

---

## Решение проблем

### "Python не найден"
Установите Python 3.11+: https://www.python.org/downloads/

### "Ошибка при установке зависимостей"
```bash
# Попробуйте вручную
pip install -r requirements.txt
```

### ".exe файл не создается"
```bash
# Установите PyInstaller
pip install pyinstaller

# Попробуйте базовую сборку
pyinstaller --onefile launcher.py
```

### "Антивирус блокирует .exe"
Это нормально для файлов созданных PyInstaller. Добавьте в исключения.

---

## Дополнительные возможности

### Добавить иконку

1. Создайте или скачайте иконку (icon.ico)
2. Измените в build_exe.py:
   ```python
   icon='icon.ico'
   ```

### Скрыть консоль

В build_exe.py измените:
```python
console=False  # вместо True
```

### Уменьшить размер .exe

```bash
# Используйте UPX компрессию
pyinstaller --onefile --upx-dir=/path/to/upx launcher.py
```

---

## Итоговая структура

```
alfa-campaign-manager/
├── START.bat              ← Двойной клик для Windows
├── start.sh               ← Запуск для Linux/macOS
├── launcher.py            ← Универсальный launcher
├── build_exe.py           ← Создание .exe файла
├── main.py                ← Основное приложение
├── setup_wizard.py        ← Мастер настройки
├── requirements.txt       ← Зависимости
├── .env                   ← Конфигурация
└── dist/
    └── AlfaCampaignManager.exe  ← Готовый .exe (после сборки)
```

---

## Быстрый старт

### Windows (самый простой способ):
1. Дважды кликните **START.bat**
2. Готово! ✅

### Windows (с .exe):
1. `python build_exe.py`
2. Дважды кликните `dist/AlfaCampaignManager.exe`
3. Готово! ✅

### Linux/macOS:
1. `./start.sh`
2. Готово! ✅

---

**Удачи! 🚀**
