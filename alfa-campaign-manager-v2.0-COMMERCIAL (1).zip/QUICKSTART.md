# ⚡ БЫСТРЫЙ СТАРТ - Alfa Campaign Manager

**5 минут до запуска!**

---

## 📦 Шаг 1: Распаковка (30 сек)

```bash
unzip alfa-campaign-manager-v2.0-COMMERCIAL.zip
cd alfa-campaign-manager
```

---

## 🔧 Шаг 2: Установка (2 мин)

```bash
# Установить Python зависимости
pip install -r requirements.txt
```

**Если ошибка с правами:**
```bash
sudo pip install -r requirements.txt
```

---

## 🎯 Шаг 3: Настройка (2 мин)

### Вариант A: Веб-интерфейс (рекомендуется)

```bash
# Запустить сервер
python main.py

# Открыть в браузере
http://localhost:8000/setup
```

Заполните форму:
1. **Telegram API** (получить на https://my.telegram.org)
   - API ID
   - API Hash
   - Номер телефона

2. **AI API** (выберите хотя бы один, оба бесплатны!)
   - **Gemini** (рекомендуется): https://makersuite.google.com/app/apikey
   - **Groq** (очень быстро): https://console.groq.com

3. Нажмите **"Сохранить"**

### Вариант B: CLI мастер

```bash
python setup_wizard.py
```

Следуйте инструкциям в терминале.

---

## 🚀 Шаг 4: Запуск (30 сек)

```bash
python main.py
```

Откройте в браузере: **http://localhost:8000**

---

## ✅ Готово!

Теперь вы можете:
- 👥 Импортировать контакты из Telegram групп
- 💬 Создавать кампании рассылок
- 🤖 Использовать ИИ для генерации сообщений
- 📊 Отслеживать статистику

---

## 🆘 Проблемы?

### "ModuleNotFoundError"
```bash
sudo pip install -r requirements.txt
```

### "Port 8000 already in use"
```bash
# Найти процесс
lsof -i :8000
# Убить процесс
kill -9 <PID>
```

### Нужна помощь?
1. Прочитайте **README.md** (полная документация)
2. Прочитайте **DEPLOYMENT_GUIDE.md** (развертывание)
3. Запустите тесты: `python test_basic.py`

---

## 📚 Дополнительная информация

- **README.md** - полная документация
- **DEPLOYMENT_GUIDE.md** - развертывание на VPS/Docker
- **FINAL_DELIVERY_REPORT.md** - отчет о проекте

---

**Удачи! 🚀**
