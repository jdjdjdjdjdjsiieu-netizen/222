import asyncio
import logging
from telethon import TelegramClient
from telethon.tl.types import InputPeerUser
from db import get_all_contacts

# --- Конфигурация ---
# ВАЖНО: Эти данные должны быть заменены на реальные данные пользователя
from config import TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_PHONE_NUMBER

# --- Конфигурация ---
API_ID = TELEGRAM_API_ID
API_HASH = TELEGRAM_API_HASH
PHONE_NUMBER = TELEGRAM_PHONE_NUMBER
SESSION_NAME = "alfa_sender_session"

# Сообщение для рассылки (замените на свое, с призывом к боту)
# ВАЖНО: Укажите здесь ссылку на Вашего Telegram-бота!
MESSAGE_TEMPLATE = """
Привет, {name}! 👋
Я нашел для тебя очень крутую возможность, связанную с Альфа-Банком. Это не просто карта, а целая система заработка.

Я запустил специального бота, который за 3 минуты подберет тебе самый выгодный продукт (карту, кредит, счет) и покажет, как на этом можно заработать.

Переходи, пока есть время: @[ИМЯ_ВАШЕГО_БОТА]
# ВАЖНО: Замените [ИМЯ_ВАШЕГО_БОТА] на реальное имя бота!
# Например: Переходи, пока есть время: @AlfaPartnerBot
Это просто, ни к чему не обязывает, но может принести тебе хороший доход. 😉
"""

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

async def send_messages():
    """
    Основная функция для подключения и рассылки сообщений.
    """
    # Инициализация клиента
    client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
    
    try:
        logging.info("Подключение к Telegram...")
        await client.start(phone=PHONE_NUMBER)
        logging.info("Подключение успешно. Аккаунт: %s", await client.get_me())

        # Получение контактов из базы данных бота
        contacts = get_all_contacts()
        if not contacts:
            logging.warning("База контактов пуста. Рассылка невозможна.")
            return

        logging.info("Найдено %d контактов для рассылки.", len(contacts))
        
        for contact in contacts:
            # contact: (id, name, phone, note)
            contact_id, name, phone, note = contact
            
            if not phone:
                logging.warning("Контакт ID %d (%s) не имеет номера телефона. Пропускаем.", contact_id, name)
                continue

            # Форматирование номера телефона для поиска
            # Telethon лучше работает с полными номерами, но мы используем то, что есть
            target_phone = phone.strip().replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
            
            # Персонализация сообщения
            first_name = name.split()[0] if name else "друг"
            message_text = MESSAGE_TEMPLATE.format(name=first_name)
            
            try:
                # Поиск пользователя по номеру телефона
                user = await client.get_entity(target_phone)
                
                # Отправка сообщения
                await client.send_message(user, message_text)
                logging.info("Сообщение успешно отправлено контакту: %s (%s)", name, target_phone)
                
                # ВАЖНО: Задержка для предотвращения блокировки
                await asyncio.sleep(5) # Рекомендуется от 5 до 15 секунд
                
            except Exception as e:
                logging.error("Ошибка при отправке контакту %s (%s): %s", name, target_phone, e)
                # Увеличиваем задержку после ошибки
                await asyncio.sleep(10)

    except Exception as e:
        logging.error("Критическая ошибка при работе клиента: %s", e)
        
    finally:
        await client.disconnect()
        logging.info("Клиент Telegram отключен.")

if __name__ == '__main__':
    # Инициализация базы данных перед запуском
    # ВАЖНО: Убедитесь, что db.py находится в той же директории
    # init_db() # База данных инициализируется при запуске main.py, но лучше убедиться
    
    # Запуск асинхронной функции
    try:
        asyncio.run(send_messages())
    except KeyboardInterrupt:
        logging.info("Рассылка прервана пользователем.")
    except Exception as e:
        logging.error("Ошибка запуска: %s", e)
